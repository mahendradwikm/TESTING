"""Transform module
"""

import tensorflow as tf
LABEL_KEY = "recalled"
FEATURE_KEY = "text"

def transformed_name(key):
    """Renaming transformed features"""
    return key + "_xf"

def preprocessing_fn(inputs):
    """
    Preprocess input features into transformed features
    
    Args:
        inputs: map from feature keys to raw features.
    
    Return:
        outputs: map from feature keys to transformed features.    
    """

    outputs = {}
    outputs[transformed_name(LABEL_KEY)] = tf.cast(inputs[LABEL_KEY], tf.int64)
    outputs[transformed_name(FEATURE_KEY)] = tf.strings.lower(inputs[FEATURE_KEY])

    def handle_none(tensor):
        return tf.where(tf.equal(tensor, None), '', tensor)

    for key, value in inputs.items():
        cleaned_value = handle_none(value)
        split_value = tf.strings.split(cleaned_value)
        outputs[key] = split_value

    def handle_none(value):
        return value if value is not None else ''

    for key, value in inputs.items():
        cleaned_value = handle_none(value)
        outputs[key] = cleaned_value.partition(" ")

    return outputs
