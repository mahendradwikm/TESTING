"""Transform module
"""

import tensorflow as tf
LABEL_KEY = "recalled"
FEATURE_KEY = "text"

def transformed_name(key):
    """Renaming transformed features"""
    return key + "_xf"

def preprocessing_fn(inputs):
    """
    Preprocess input features into transformed features
    
    Args:
        inputs: map from feature keys to raw features.
    
    Return:
        outputs: map from feature keys to transformed features.    
    """
    outputs = {}

    def handle_none(tensor, dtype):
        if dtype == tf.string:
            return tf.where(tf.equal(tensor, None), '', tensor)
        elif dtype == tf.int64 or dtype == tf.float32:
            return tf.where(tf.equal(tensor, None), tf.constant(0, dtype=dtype), tensor)
        else:
            raise ValueError(f"Unsupported dtype: {dtype}")
        
    outputs[transformed_name(LABEL_KEY)] = tf.cast(inputs[LABEL_KEY], tf.int64)
    outputs[transformed_name(FEATURE_KEY)] = tf.strings.lower(inputs[FEATURE_KEY])

    text = handle_none(inputs[FEATURE_KEY], tf.string)
    outputs[transformed_name(FEATURE_KEY)] = tf.strings.lower(text)

    for key, value in inputs.items():
        if key not in [LABEL_KEY, FEATURE_KEY]:
            dtype = value.dtype
            value = handle_none(value, dtype)
            if dtype == tf.string:
                split_value = tf.strings.split(value)
                outputs[transformed_name(key)] = split_value
            else:
                outputs[transformed_name(key)] = value

    return outputs
