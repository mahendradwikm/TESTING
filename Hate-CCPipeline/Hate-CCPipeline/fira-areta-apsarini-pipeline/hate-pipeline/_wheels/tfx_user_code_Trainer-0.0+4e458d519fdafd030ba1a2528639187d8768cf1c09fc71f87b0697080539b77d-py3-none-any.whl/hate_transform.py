import tensorflow as tf
import tensorflow_transform as tft

LABEL_KEY = "recalled"
FEATURE_KEY = "text"

def transformed_name(key):
    """Renaming transformed features"""
    return key + "_xf"

def handle_none(tensor, dtype):
    if dtype == tf.string:
        # Replace None or empty strings with an empty string
        tensor = tf.where(tf.equal(tensor, None), tf.constant('', dtype=dtype), tensor)
        tensor = tf.where(tf.equal(tensor, ''), tf.constant('', dtype=dtype), tensor)
        return tensor
    elif dtype == tf.int64 or dtype == tf.float32:
        # Replace None with a default value for numerical types
        default_value = tf.constant(0, dtype=dtype)
        tensor = tf.where(tf.equal(tensor, None), default_value, tensor)
        return tensor
    else:
        raise ValueError(f"Unsupported dtype: {dtype}")

def preprocessing_fn(inputs):
    """
    Preprocess input features into transformed features
    
    Args:
        inputs: map from feature keys to raw features.
    
    Return:
        outputs: map from feature keys to transformed features.    
    """
    outputs = {}

    # Transform the label and handle None
    label = handle_none(inputs[LABEL_KEY], tf.int64)
    outputs[transformed_name(LABEL_KEY)] = tf.cast(label, tf.int64)

    # Transform the text feature and handle None
    text = handle_none(inputs[FEATURE_KEY], tf.string)
    outputs[transformed_name(FEATURE_KEY)] = tf.strings.lower(text)

    # Handle other features if present
    for key, value in inputs.items():
        if key not in [LABEL_KEY, FEATURE_KEY]:
            dtype = value.dtype
            value = handle_none(value, dtype)
            if dtype == tf.string:
                split_value = tf.strings.split(value)
                outputs[transformed_name(key)] = split_value
            else:
                outputs[transformed_name(key)] = value

    return outputs